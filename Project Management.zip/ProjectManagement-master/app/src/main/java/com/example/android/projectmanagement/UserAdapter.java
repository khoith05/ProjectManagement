package com.example.android.projectmanagement;

import android.content.Context;
import android.content.Intent;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.PopupMenu;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class UserAdapter extends RecyclerView.Adapter<UserAdapter.ItemViewHolder>{

    private List<item_proj> mListItem;

    public UserAdapter(List<item_proj> ListItem) {
        this.mListItem = ListItem;
    }

    @NonNull
    @Override
    public ItemViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view= LayoutInflater.from(parent.getContext()).inflate(R.layout.item_project,parent,false);
        return new ItemViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ItemViewHolder holder, int position) {
        item_proj item = mListItem.get(position);
        if (item==null){
            return;
        }
        holder.name.setText(item.getName());
        holder.des.setText(item.getDescription());

    }


    private void onClickgotoTask(item_proj item){
        Intent intent =new Intent();
    }

    @Override
    public int getItemCount() {
        if (mListItem!=null){
            return mListItem.size();
        }
        return 0;
    }

    public class ItemViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener, PopupMenu.OnMenuItemClickListener {

        private TextView name;
        private TextView des;
        private TextView date;
        private ImageButton dots;
        private RelativeLayout layout_item;

        public ItemViewHolder(@NonNull View itemView) {
            super(itemView);
            layout_item= itemView.findViewById(R.id.card_project);
            name= itemView.findViewById(R.id.name);
            des= itemView.findViewById(R.id.description);
            date= itemView.findViewById(R.id.date);
            dots= itemView.findViewById(R.id.dots);
            dots.setOnClickListener(this);

        }

        @Override
        public void onClick(View view) {
            showPopupMenu(view);
        }

        private void showPopupMenu(View view){
            PopupMenu popupMenu = new PopupMenu(view.getContext(),view);
            popupMenu.inflate(R.menu.option_menu);
            popupMenu.setOnMenuItemClickListener(this);
            popupMenu.show();
        }

        @Override
        public boolean onMenuItemClick(MenuItem menuItem) {
            switch (menuItem.getItemId()){
                case R.id.Edit:
                    Log.d("nut","pro");

                    return true;
                case R.id.delete:
                    mListItem.remove(getAdapterPosition());
                    notifyItemRemoved(getAdapterPosition());
                    return true;
                default:
                    return false;
            }
        }
    }
}
