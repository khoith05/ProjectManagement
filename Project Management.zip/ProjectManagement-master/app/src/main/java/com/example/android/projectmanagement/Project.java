package com.example.android.projectmanagement;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.PopupMenu;
import android.widget.Toast;
import android.widget.Toolbar;

import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;

public class Project extends Fragment {

    private RecyclerView recyclerView;
    private UserAdapter itemAdapter;

    public Project(){

    }
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        getActivity().setTitle("Project");
        View view=inflater.inflate(R.layout.fragment_project, container, false);

        recyclerView = view.findViewById(R.id.rsv_data);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(view.getContext()));
        itemAdapter= new UserAdapter(getItemPro());
        recyclerView.setAdapter(itemAdapter);

        return view;

    }



    private List<item_proj> getItemPro(){
        List<item_proj> list =new ArrayList<>();
        list.add(new item_proj(1,"du an 1","gan chet","2021-11-20","20/11/2021",1));
        list.add(new item_proj(1,"du an 2","gan chet","2021-11-20","20/11/2021",1));
        list.add(new item_proj(1,"du an 3","gan chet","2021-11-20","20/11/2021",1));
        list.add(new item_proj(1,"du an 4","gan chet","2021-11-20","20/11/2021",1));
        list.add(new item_proj(1,"du an 5","gan chet","2021-11-20","20/11/2021",1));
        list.add(new item_proj(1,"du an 6","gan chet","2021-11-20","20/11/2021",1));
        list.add(new item_proj(1,"du an 7","gan chet","2021-11-20","20/11/2021",1));
        list.add(new item_proj(1,"du an 8","gan chet","2021-11-20","20/11/2021",1));
        list.add(new item_proj(1,"du an 9","gan chet","2021-11-20","20/11/2021",1));
        list.add(new item_proj(1,"du an 10","gan chet","2021-11-20","20/11/2021",1));
        list.add(new item_proj(1,"du an 11","gan chet","2021-11-20","20/11/2021",1));
        list.add(new item_proj(1,"du an 12","gan chet","2021-11-20","20/11/2021",1));
        return list;
    }

}