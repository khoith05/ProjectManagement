package com.example.android.projectmanagement;

import java.util.Date;

public class item_proj {

    private int ID;
    private String name;
    private String description;
    private String start;
    private String end;
    private int state;

    public item_proj(int ID, String name, String description, String start, String end, int state) {
        this.ID = ID;
        this.name = name;
        this.description = description;
        this.start = start;
        this.end = end;
        this.state = state;
    }

    public int getID() {
        return ID;
    }

    public void setID(int ID) {
        this.ID = ID;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getStart() {
        return start;
    }

    public void setStart(String start) {
        this.start = start;
    }

    public String getEnd() {
        return end;
    }

    public void setEnd(String end) {
        this.end = end;
    }

    public int getState() {
        return state;
    }

    public void setState(int state) {
        this.state = state;
    }
}
